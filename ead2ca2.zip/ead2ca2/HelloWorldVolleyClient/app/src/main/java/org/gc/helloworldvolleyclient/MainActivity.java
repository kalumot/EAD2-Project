// add Internet permission

package org.gc.helloworldvolleyclient;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

// in build.gradle for Module:app
// implementation 'com.android.volley:volley:1.1.1'
// implementation 'com.google.code.gson:gson:2.8.5'

public class MainActivity extends AppCompatActivity
{

    // uri of RESTful service on Azure
    private String SERVICE_URI = "https://ead2ca2api.azurewebsites.net/api/team/all";
    private String MATCH_URI = "https://ead2ca2api.azurewebsites.net/api/match/all";
    private String TAG = "helloworldvolleyclient";
    List<Team> clubs = new ArrayList<Team>() {
    };
    List<String> names = new ArrayList<String>() {
    };
    //TextView nametest = (TextView) findViewById(R.id.outputTextView);


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner dynamicSpinner = (Spinner) findViewById(R.id.dynamic_spinner);
        RequestQueue queue = Volley.newRequestQueue(this);

        //teams for spinner
        try
        {
            StringRequest strObjRequest = new StringRequest(Request.Method.GET, SERVICE_URI,
                    new Response.Listener<String>()
                    {
                        @Override
                        public void onResponse(String response)
                        {
                            // parse resulting string containing JSON to Greeting object
                            List<Team> teams = new Gson().fromJson(response, new TypeToken<List<Team>>(){}.getType());
                            makeSpinner(teams);
                            Log.d(TAG, "Displaying data" + teams.toString());
                            
                        }
                    },
                    new Response.ErrorListener()
                    {
                        @Override
                        public void onErrorResponse(VolleyError error)
                        {
                            Log.d(TAG, "Error" + error.toString());
                        }
                    });
            queue.add(strObjRequest);           // can have multiple in a queue, and can cancel
        }
        catch (Exception e1)
        {
            Log.d(TAG, e1.toString());
        }

        //matches ----------------------------------------------------------------------------------------
        RequestQueue queue2 = Volley.newRequestQueue(this);
        try
        {
            StringRequest strObjRequest = new StringRequest(Request.Method.GET, MATCH_URI,
                    new Response.Listener<String>()
                    {
                        @Override
                        public void onResponse(String response)
                        {
                            // parse resulting string containing JSON to Greeting object
                            List<Match> matches = new Gson().fromJson(response, new TypeToken<List<Match>>(){}.getType());
                            TextView match1 = (TextView) findViewById(R.id.match1);
                             match1.setText(matches.get(0).toString());
                            TextView match2 = (TextView) findViewById(R.id.match2);
                            match2.setText(matches.get(1).toString());
                            TextView match3 = (TextView) findViewById(R.id.match3);
                            match3.setText(matches.get(2).toString());
                            TextView match4 = (TextView) findViewById(R.id.match4);
                            match4.setText(matches.get(3).toString());
                            TextView match5 = (TextView) findViewById(R.id.match5);
                            match5.setText(matches.get(4).toString());

                            Log.d(TAG, "Displaying data" + matches.toString());

                        }
                    },
                    new Response.ErrorListener()
                    {
                        @Override
                        public void onErrorResponse(VolleyError error)
                        {
                            Log.d(TAG, "Error" + error.toString());
                        }
                    });
            queue2.add(strObjRequest);           // can have multiple in a queue, and can cancel
        }
        catch (Exception e1)
        {
            Log.d(TAG, e1.toString());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, names);

        dynamicSpinner.setAdapter(adapter);

        dynamicSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                Log.v("item", (String) parent.getItemAtPosition(position));
                String selected = parent.getItemAtPosition(position).toString();
                TextView testy = (TextView) findViewById(R.id.testy);
                testy.setText("haha");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                TextView testy = (TextView) findViewById(R.id.testy);
                testy.setText("gaaaaa");
            }
        });
    }

    public void makeSpinner(List<Team> t)
    {
        for(int i = 0; i < t.size(); i++){
          names.add(t.get(i).name);
        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        return super.onOptionsItemSelected(item);
    }


}




