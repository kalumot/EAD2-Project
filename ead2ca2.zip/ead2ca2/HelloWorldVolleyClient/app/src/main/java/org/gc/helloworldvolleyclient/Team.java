package org.gc.helloworldvolleyclient;

// model class with matching instance vars
public class Team
{
    private int id;
    public String name;
    private String code;


    public String toString()
    {
        return "" + name;
    }
}