package org.gc.helloworldvolleyclient;

// model class with matching instance vars
public class Team
{
    private int id;
    public String name;
    public String code;


    public String toString()
    {
        return "" + name;
    }
}