package org.gc.helloworldvolleyclient;

public class Match {
    public int id;
    private Team home;
    private Team away;
    private int homeScore;
    private int awayScore;

    public String toString()
    {
        return home.toString() + "| " + homeScore + ":" + awayScore + " |" + away.toString();
    }
}
